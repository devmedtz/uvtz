<?php

namespace App\Http\Livewire\Payroll;

use Livewire\Component;

class PayrollPayment extends Component
{

    public function render()
    {
        return view('livewire.payroll.payroll-payment');
    }
}
