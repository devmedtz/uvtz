<?php

namespace App\Http\Livewire\Admin\System;

use Livewire\Component;

class SystemSettings extends Component
{
    public function render()
    {
        return view('livewire.admin.system.system-settings');
    }
}
