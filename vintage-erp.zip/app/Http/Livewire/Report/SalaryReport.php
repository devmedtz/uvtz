<?php

namespace App\Http\Livewire\Report;

use Livewire\Component;

class SalaryReport extends Component
{
    public function render()
    {
        return view('livewire.report.salary-report');
    }
}
