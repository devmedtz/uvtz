<?php

namespace App\Http\Livewire\Report;

use Livewire\Component;

class PurchaseReport extends Component
{
    public function render()
    {
        return view('livewire.report.purchase-report');
    }
}
