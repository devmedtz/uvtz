<div>
    <!-- START: Breadcrumbs-->
    <div class="row">
        <div class="col-12  align-self-center">
            <div class="sub-header mt-3 py-3 align-self-center d-sm-flex w-100 rounded">
                <div class="w-sm-100 mr-auto"><h4 class="mb-0">Material: <strong class="text-secondary"><?php echo e($prodMaterials->material_name); ?></strong></h4> <p>Details of Production Materials</p></div>
                </ol>
            </div>
        </div>
    </div>
    <!-- END: Breadcrumbs-->
    <!-- START: Card Data-->
    <div class="row">
        <div class="col-md-6 col-sm-12 col-lg-6 mt-3">
            <div class="card">
                <div class="card-header  justify-content-between align-items-center">
                    <h4 class="card-title text-secondary">Usage History (Total Used: <?php echo e($usage->sum('qty')); ?>)</h4>
                </div>
                <div class="card-body">
                    <input type="text" class="form-control col-md-6 col-sm-12" placeholder="Search......"/>
                    <div class="table-responsive mt-3">
                        <table class="table table-sm table-centered mb-0" >
                            <thead>
                            <tr>
                                <th>Date</th>
                                <th>Qty</th>
                                <th>Reason</th>
                                <th>User</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $usage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $used): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($used->mat_date); ?></td>
                                        <td><?php echo e($used->qty); ?></td>
                                        <td><?php echo e($used->material_note); ?></td>
                                        <td><?php echo e($used->created_by); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-12 col-lg-6 mt-3">
            <div class="card">
                <div class="card-header  justify-content-between align-items-center">
                    <h4 class="card-title text-success">Addition History (Total Addition: <?php echo e($additions->sum('qty')); ?>)</h4>
                </div>
                <div class="card-body">
                    <input type="text" class="form-control col-md-6 col-sm-12" placeholder="Search......"/>
                    <div class="table-responsive mt-3">
                        <table class="table table-sm table-centered mb-0" >
                            <thead>
                            <tr>
                                <th>Date</th>
                                <th>Qty</th>
                                <th>Note</th>
                                <th>User</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $additions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($addition->mat_date); ?></td>
                                        <td><?php echo e($addition->qty); ?></td>
                                        <td><?php echo e($addition->material_note); ?></td>
                                        <td><?php echo e($addition->created_by); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END: Card DATA-->
</div>
<?php /**PATH C:\xampp\htdocs\vintage-erp\resources\views/livewire/production/production-details.blade.php ENDPATH**/ ?>